# LLM Distillation Project

Este projeto implementa a destilação de modelos de linguagem (LLM) usando PyTorch e Hugging Face.

## 📌 Como usar

### Instalar dependências:
```bash
pip install -r requirements.txt
```

### Treinar o modelo destilado:
```bash
python main.py --epochs 5 --lr 3e-5
```

## 📚 Estrutura

- **scripts/** → Scripts de treinamento e avaliação
- **models/** → Modelos treinados e checkpoints
- **data/** → Conjunto de dados
- **notebooks/** → Notebooks para experimentação
