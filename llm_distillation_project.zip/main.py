import argparse
from scripts.train_distillation import train_student

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Treinamento de um modelo destilado")
    parser.add_argument("--epochs", type=int, default=3, help="Número de épocas")
    parser.add_argument("--lr", type=float, default=5e-5, help="Taxa de aprendizado")
    args = parser.parse_args()

    print("Iniciando treinamento do modelo distilado...")
    train_student(epochs=args.epochs, lr=args.lr)
