import torch
import torch.nn as nn
from transformers import BertForSequenceClassification, DistilBertForSequenceClassification
from torch.utils.data import DataLoader, TensorDataset
import torch.optim as optim
from tqdm import tqdm

teacher = BertForSequenceClassification.from_pretrained("bert-base-uncased")
student = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased")
teacher.eval()

inputs = torch.randint(0, 10000, (10, 128))
labels = torch.randint(0, 2, (10,))
dataset = TensorDataset(inputs, labels)
dataloader = DataLoader(dataset, batch_size=2)

class DistillationLoss(nn.Module):
    def __init__(self, temperature=2.0):
        super().__init__()
        self.temperature = temperature
        self.kl_div = nn.KLDivLoss(reduction="batchmean")

    def forward(self, student_logits, teacher_logits):
        student_probs = torch.nn.functional.log_softmax(student_logits / self.temperature, dim=-1)
        teacher_probs = torch.nn.functional.softmax(teacher_logits / self.temperature, dim=-1)
        return self.kl_div(student_probs, teacher_probs)

def train_student(teacher, student, dataloader, epochs=3, lr=5e-5):
    criterion = DistillationLoss(temperature=2.0)
    optimizer = optim.AdamW(student.parameters(), lr=lr)
    
    student.train()
    for epoch in range(epochs):
        loop = tqdm(dataloader, leave=True)
        for batch in loop:
            inputs, _ = batch
            
            with torch.no_grad():
                teacher_logits = teacher(inputs).logits
            
            student_logits = student(inputs).logits
            loss = criterion(student_logits, teacher_logits)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            loop.set_description(f"Epoch {epoch+1}")
            loop.set_postfix(loss=loss.item())

train_student(teacher, student, dataloader)
